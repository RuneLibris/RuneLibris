# -*- coding: ansi -*-

def replace_special_chars(input_file, output_file, replacements):
    # Read the input file
    try:
        with open(input_file, 'r', encoding='ansi') as file:
            content = file.read()
    except FileNotFoundError:
        print(f"Error: Input file '{input_file}' not found.")
        return
    except Exception as e:
        print(f"Error reading file: {e}")
        return

    # Perform all replacements
    for old_str, new_str in replacements:
        content = content.replace(old_str, new_str)

    # Write to output file
    try:
        with open(output_file, 'w', encoding='ansi') as file:
            file.write(content)
        print(f"Successfully wrote output to {output_file}")
    except Exception as e:
        print(f"Error writing to output file: {e}")

# Define your replacements using triple quotes
replacements = [
    ("""A "fishy" key (Jerome's)""", """� C c C c � � C c C c � � d D d � � �"""),
    ("""� � � � � � � � � � A a A a A a A a �""", """� C c C c � � C c C c � � d D d � � �"""),
    ("""e E e E e G g G g G g G g H h H h � �""", """L l N n � � N n N n � � � � � � � � �""")
]

# Usage
input_file = "input.txt"  # Replace with your input file path
output_file = "output.txt"
replace_special_chars(input_file, output_file, replacements)