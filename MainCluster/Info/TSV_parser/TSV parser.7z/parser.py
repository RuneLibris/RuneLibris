import csv

# Define the subjects we want to extract
target_subjects = [
    "RS/Locs/Intricate lock (ID 122127)",
    "RS/Locs/Intricate lock (ID 122128)"
]

# Define input and output file paths
input_file = "input.tsv"    # Replace with your input file path
output_file = "output.txt"  # Replace with your desired output file path

# Read the TSV and write matching entries to output file
with open(input_file, 'r', encoding='utf-8') as infile:
    # Create TSV reader with tab delimiter
    tsv_reader = csv.DictReader(infile, delimiter='\t')
    
    # Open output file for writing
    with open(output_file, 'w', encoding='utf-8') as outfile:
        # Process each row
        for row in tsv_reader:
            if row['Subject'] in target_subjects:
                # Write matching entries in TSV format
                outfile.write(f"{row['Subject']}\t{row['Examine']}\n")

print(f"Extraction complete. Results written to {output_file}")