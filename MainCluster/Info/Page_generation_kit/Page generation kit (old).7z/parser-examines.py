import csv

# Define the subjects we want to extract
target_subjects = [
    "RS/Items/Burnt meat (ID 2146)",
    "RS/Items/Eye of newt (ID 221)",
    "RS/Items/Onion (ID 1957)",
    "RS/Items/Rat's tail (ID 300)",
    "RS/Locs/Cauldron (ID 14338)",
    "RS/Locs/Cauldron (ID 14339)",
    "RS/NPCs/Hetty (ID 307)"
]

# Define input and output file paths
input_file = "examines.tsv"    # Replace with your input file path
output_file = "output-examines.txt"  # Replace with your desired output file path

# Read the TSV and write matching entries to output file
with open(input_file, 'r', encoding='utf-8') as infile:
    # Create TSV reader with tab delimiter
    tsv_reader = csv.DictReader(infile, delimiter='\t')
    
    # Open output file for writing
    with open(output_file, 'w', encoding='utf-8') as outfile:
        # Process each row
        for row in tsv_reader:
            if row['Subject'] in target_subjects:
                # Write matching entries in TSV format
                outfile.write(f"{row['Subject']}\t{row['Examine']}\n")

print(f"Extraction complete. Results written to {output_file}")