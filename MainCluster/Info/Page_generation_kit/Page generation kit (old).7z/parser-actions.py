import csv

# Define the subjects we want to extract
target_subjects = [
    "RS/Items/Burnt meat (ID 2146)",
    "RS/Items/Eye of newt (ID 221)",
    "RS/Items/Onion (ID 1957)",
    "RS/Items/Rat's tail (ID 300)",
    "RS/Locs/Cauldron (ID 14338)",
    "RS/Locs/Cauldron (ID 14339)",
    "RS/NPCs/Hetty (ID 307)"
]

# Define input and output file paths
input_file = "actions.tsv"    # Replace with your input file path
output_file = "output-actions.txt"  # Replace with your desired output file path

# Read the TSV and write matching entries to output file
with open(input_file, 'r', encoding='ansi') as infile:
    # Create TSV reader with tab delimiter
    tsv_reader = csv.DictReader(infile, delimiter='\t')
    
    # Open output file for writing
    with open(output_file, 'w', encoding='ansi') as outfile:
        # Process each row
        for row in tsv_reader:
            if row['Subject'] in target_subjects:
                # Write matching entries in TSV format
                outfile.write(f"{row['Subject']}\t{row['OP0']}\t{row['OP1']}\t{row['OP2']}\t{row['OP3']}\t{row['OP4']}\t{row['Member OP0']}\t{row['Member OP1']}\t{row['Member OP2']}\t{row['Member OP3']}\t{row['Member OP4']}\t{row['Ground OP0']}\t{row['Ground OP1']}\t{row['Ground OP2']}\t{row['Ground OP3']}\t{row['Ground OP4']}\n")

print(f"Extraction complete. Results written to {output_file}")