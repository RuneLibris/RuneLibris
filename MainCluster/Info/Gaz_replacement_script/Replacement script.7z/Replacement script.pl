#! perl
use warnings;
use strict;

#$ARGV[0] = input file

my %replacements = (
    "__1__" => 'Toolkit',
    "__100__" => 'Ranarr potion (unf)'
);
my %qrepl;
foreach my $k (keys %replacements) {
    $qrepl{quotemeta($k)} = $replacements{$k};
}
my @keys = keys %qrepl;


my $filename = $ARGV[0];
print "opening $filename...\n";
my $encoding = ":encoding(UTF-8)";
my $input   = undef;     # this will be filled in on success
open($input, "< $encoding", $filename)
        || die "$0: can't open $filename for reading: $!";
$filename =~ s/(\.\w+)?$/_out$1/;
print "opening $filename...\n";
my $output   = undef;     # this will be filled in on success
open($output, "> $encoding", $filename)
        || die "$0: can't open $filename for reading: $!";

print "opened!\nstarting to read...\n\n";

my $line;
my $repl;
while ($line = <$input>) {
    chomp $line;
    foreach my $item (@keys) {
        if ($line =~ m/ ?$item ?/) {
            print "replacing $item in $line\n";
            $repl = $qrepl{$item};
            $line =~ s/( ?)$item( ?)/${1}${repl}${2}/;
            last;
        }
    }
    print $output "$line\n";
}

print "done!\n";