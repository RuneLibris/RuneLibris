import json

def parse_json_file(input_file_path, output_file_path):
    try:
        # Read the JSON file
        with open(input_file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
        
        # Open output file for writing
        with open(output_file_path, 'w', encoding='utf-8') as output:
            # Access the "files" array
            files = data.get('files', [])
            
            # Iterate through each entry in files
            for index, entry in enumerate(files, 1):
                # Get values with empty string as default if key doesn't exist
                name = entry.get('name', '')
                examine = entry.get('examine', '')
                file_id = entry.get('$fileid', '')  # Note: using $fileid instead of fileID
                
                # Write to output file
                output.write(f"{file_id}"+"__"+f"{name}"+"__"+f"{examine}\n")
                
        print(f"Successfully parsed JSON and saved to {output_file_path}")
        
    except FileNotFoundError:
        print("Error: Input file not found")
    except json.JSONDecodeError:
        print("Error: Invalid JSON format")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

# Usage example
input_file = "data.json"
output_file = "output.txt"
parse_json_file(input_file, output_file)